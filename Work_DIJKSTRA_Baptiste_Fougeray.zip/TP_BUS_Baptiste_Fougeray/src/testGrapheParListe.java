import java.io.IOException;


public class testGrapheParListe {

	public static void main(String[] args) throws IOException {
		//GrapheParListe g = new GrapheParListe();
		//g.afficherGraphe();
		//g.plusCourtChemin(0);
		
		GrapheParListe g = new GrapheParListe("NomFichier.CSV");
		g.afficherGraphe();
		
		g.plusCourtChemin(0);
		
	}

}