public class Element {
	int sommet; 
	//on code le numéro d'un sommet par un entier
	int distance; 
	//distance vers le sommet source
	Element(int s, int d){
		sommet=s;
		distance=d;
	}
}