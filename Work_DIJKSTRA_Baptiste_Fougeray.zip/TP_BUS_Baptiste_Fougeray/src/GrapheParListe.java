import utilensemjava.Lecture;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class GrapheParListe {
	//un tableau de listes chaînées comme attribut
	public Liste adj []; 

	//constructeur qui demande la saisie mannuel du graphe
	GrapheParListe(int nb_sommets,	int	nb_arcs){
		adj	= new	Liste[nb_sommets];
		for(int	i = 0; i < nb_sommets; i++) 
			adj[i] = null;
		//on saisie les arcs par sommet du départ
		for(int	k=0; k<nb_arcs; k++) {
			int	i = Lecture.lireEntier("sommet sortant du "	+(k+1)+"ème arc (0-"+(nb_sommets-1)+")=? ");
			int	j = Lecture.lireEntier("sommet d'arrivée du "+(k+1)+"ème arc (0-"+(nb_sommets-1)+")=? ");
			int	val=Lecture.lireEntier("valeur du "+(k+1)+"ème arc =? ");
			adj[i] = new Liste(j,adj[i], val);
		}
	}
	
	//Constructeur avec le graphe fixe du cours, pour un exemple
	GrapheParListe()
		{
			adj=new Liste[6];
			for(int i=0 ; i<adj.length ; i++) 
			{	adj[i]=null;	}

			//On saisie les arcs
			adj[0]=new Liste(3,adj[0],10);
			adj[0]=new Liste(1,adj[0],1);
			adj[1]=new Liste(4,adj[1],1);
			adj[1]=new Liste(3,adj[1],8);
			adj[1]=new Liste(2,adj[1],7);
			adj[4]=new Liste(3,adj[4],4);
			adj[4]=new Liste(2,adj[4],2);
			adj[5]=new Liste(3,adj[5],2);
		}
		
	//Constructeur pour lire le graphe a partir d'un fichier texte
	GrapheParListe(String nomFichier) throws IOException {
			//compter le nombre de lignes du fichier nomFichier qui correspond au nombre de sommets
			int nb_sommets=compterLigne(nomFichier);
			//On cree la liste d'adjacence vide avec le nombre de noeuds donne par nb_sommets
			adj=new Liste[nb_sommets];
			for(int i=0 ; i<nb_sommets ; i++) adj[i]=null;

			//On lit ligne par ligne le graphe à partir d'un fichier
			File f = new File(nomFichier);
				BufferedReader fR = new BufferedReader(new FileReader(f));
				String chaine ="";
				String [] noeud;
		        do {
		        	chaine = fR.readLine();
		        	//pour visualiser la ligne lue:
		        	if (chaine != null) {
		        		//System.out.println(chaine);
		        		noeud=chaine.split(",");
		        		int lg_liste=(noeud.length-1)/2; // nombre de noeuds dans une liste chainee
		        		for (int i=0;i<lg_liste;i++) {
		        			adj[Integer.parseInt(noeud[0])]=
		        				 new Liste(Integer.parseInt(noeud[2*i+1]),
		            adj[Integer.parseInt(noeud[0])],Integer.parseInt(noeud[2*i+2]));
		        			}
		        	}
		        } while (chaine != null);
		        fR.close();
	}

	//compter le nombre de lignes du fichier nomFichier
	private int compterLigne(String nomFichier) throws IOException {
		File f = new File(nomFichier);
		BufferedReader fR = new BufferedReader(new FileReader(f));
		String chaine ="";
		int nb_ligne=0;
        do {
        	chaine = fR.readLine();
        	if (chaine != null) nb_ligne++;
        } while (chaine != null);
        fR.close();
        System.out.println("nombre de sommets du fichier est : " + nb_ligne);
        return nb_ligne;
	}
	//affichage du graphe: liste de noeuds connectés à partir d'un 	sommet sortant

	public void afficherGraphe(){
		for(int	i = 0; i < 	adj.length; i++){
			System.out.print("sommet "+i+" : ");
			if(adj[i]!=	null) {
				Liste a = adj[i];
				while(a!=null) {
					System.out.print("s"+a.num_noeud+ " " + a.valeur+ " ");

					if(a.suivant!= null	) 
						System.out.print("|"+a.	suivant.num_noeud+" -> ");
					a = a.suivant;
				}
			}
			System.out.println(" null");
		}
	}
	
	//tester s'il existe un arc entre deux sommets
	public boolean arc (int	source,	int	dest){
		boolean	arcExiste= false;
		if(	adj[source]!=null) {
			Liste a = adj[source];
			while(a !=null) {
				if(a.num_noeud== dest) arcExiste =true;
				if(arcExiste) a=null;
				else
					a = a.suivant;
			}
		}
		return	arcExiste;
	}

	//retruner la valeur de l'arc entre deux sommets
	public  int valeurArc(int source,int	dest){
		int	val = 9999;
		boolean	arcExiste=false;
		Liste a = adj[source];
		while(a !=null) {
			if(a.num_noeud== dest) {
				val = a.valeur; 
				arcExiste =true;
			}
			if(arcExiste) a=null;
			else	a = a.suivant;
		}
		return	val;
	}

	//rechercher le plus court chemin d'un sommet source vers tous les autres noeuds
	public	Vector<Element> plusCourtChemin(	int	num_sommet){
		final int INFINI = Integer.MAX_VALUE;
		Vector<Element> S = new	Vector<Element>(); 
		//vector de solution
		Vector<Element> D = new Vector<Element>(); 
		//vector du départ
		//initialiser l'ensemble D
		for(int	i = 0; i <adj.length; i++){
			if(i!=num_sommet)D.addElement(new Element(i,INFINI));
			else
				D.addElement(new Element(i,0));
		}
		System.out.println("S:");
		for(int i = 0; i < S.size(); i++){
			System.out.println(((Element)S.elementAt(i)).sommet	+","+((Element)S.elementAt(i)).	distance);
		}
		System.out.println(	"D:");
		for(int	i = 0; i < D.size(); i++){

			System.out.println(((Element)D.elementAt(i)).sommet+","+((Element)D.elementAt(i)).distance);
		}
		//construire l'ensemble S selon Dijkstra
		while(D.size()!=0){
			//on cherchel'élément qui a la plus petite distance
			int	indice_min=0;
			int	dm=INFINI;
			int	sm=((Element) D.elementAt(0)).sommet;
			for	(int i = 0; i < D.size(); i++){
				if(dm > ((Element) D.elementAt(i)).	distance){
					dm = ((Element) D.elementAt(i)).distance;
					sm = ((Element) D.elementAt(i)).sommet;
					indice_min = i;
				}
			}
			Element m = new	Element(sm,dm);
			//on l'ajoute dans S puis on le supprime de D
			S.addElement(m);
			System.out.println("S après avec taille= "+S.size());
			for(int	i = 0; i < S.size(); i++){
				System.out.println(((Element)S.elementAt(i)).sommet+","+((Element)S.elementAt(i)).distance);
			}
			D.removeElementAt(indice_min);
			System.out.println("D après avec taille= "+D.size());
			for(int	i = 0; i < D.size(); i++){
				System.out.println(((Element)D.elementAt(i)).sommet+","+((Element)D.elementAt(i)).distance);
			}
			// if (D.removeElement((Element) m)==false) 
			System.out.println("élément à supprimer n'est pas trouvé");
			//on recalcule dx pour tout sommet x de D qui possède un arc avec m
			for(int	i = 0; i < D.size(); i++){
				Element x = (Element) D.elementAt(i);
				if(arc(m.sommet,x.sommet)) {
					int	d=m.distance+valeurArc(m.sommet	,x.sommet);
					if	(d < x.distance) {
						x.distance=d;
						D.setElementAt(x,i);
					}
				}
			}
		}
		return	S;
	}
	
}

