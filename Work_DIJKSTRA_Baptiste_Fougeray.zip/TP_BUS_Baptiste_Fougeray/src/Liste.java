public class Liste{
	int num_noeud;
	int valeur;
	
	Liste suivant;
	
	Liste (int n, Liste t, int v){
		num_noeud = n ;
		suivant = t;
		valeur=v;
	}
}