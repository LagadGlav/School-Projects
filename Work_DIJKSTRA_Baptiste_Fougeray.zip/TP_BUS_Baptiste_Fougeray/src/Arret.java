

public class Arret {
	int X;
	int Y;
	public String nom;
	
	Arret(String nom, int coordX, int coordY){
		this.X = coordX;
		this.Y = coordY;
		this.nom= nom;
	}
	
public double distance_Arret(Arret A) {
 double a = Math.sqrt(Math.pow(this.X-A.X, 2)+Math.pow(this.Y-A.Y, 2));
 return a;
}


}
