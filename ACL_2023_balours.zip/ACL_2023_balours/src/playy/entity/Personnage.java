package playy.entity;

import playy.entity.Hero;
import playy.entity.Monstre;

//Personnage.java
public class Personnage {
 private Hero heros;
 private Monstre monstre;

 // Constructeur
 public Personnage(Hero heros, Monstre monstre) {
     this.heros = heros;
     this.monstre = monstre;
 }


}

