// serveur.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>

#define PORT 8080
#define TAILLE_MSG 1024

pthread_mutex_t mutex_r = PTHREAD_MUTEX_INITIALIZER;

void gen_plateau_Reseau(void *arg){
    Plateau *p1 = (Plateau *)arg;
    time_t t;
    srand((unsigned) time(&t));
    for(int i = 0; i<p1->L; i++){
       for(int j = 0; j<p1->C; j++){
            if (i==0 || j==0 || i==p1->L-1 || j==p1->C-1 || rand() % 100>=90){
                p1->plateau[i][j] = 1;
            }
            else{p1->plateau[i][j]= 0;}
        }
    }
}


void *affichage_Reseau(void *arg) {
    Plateau *pl = (Plateau *)arg;
    int k = 0;
    while (k<25) {
        pthread_mutex_lock(&mutex_r);
        printf("\n");
        for (int i = 0; i < pl->L; i++) {
            for (int j = 0; j < pl->C; j++) {
                if (pl->plateau[i][j] == 1) {
                    printf("#");
                } else if (pl->plateau[i][j] == 0) {
                    printf(" ");
                } else if (pl->plateau[i][j] == 3) {
                    printf("|");
                } else if (pl->plateau[i][j] == 4) {
                    printf("-");
                } else if (pl->plateau[i][j] == 2) {
                    printf("+");
                } else if (p1->plateau[i][j] == 5) {
                    printf("^");
                } else if (p1->plateau[i][j] == 6) {
                    printf("<");
                } else if (p1->plateau[i][j] == 7) {
                    printf("v");
                } else if (p1->plateau[i][j] == 8) {
                    printf(">");
                }
                printf(" ");
            }
            printf("\n");
        }
        pthread_mutex_unlock(&mutex_r);
        usleep(1000000); // Pause de 0.5 seconde (500 000 microsecondes)
    k++;
    }
    return NULL;
}


void *deplacer_drone_Reseau(void *arg){
    Drone *drones = (Drone *)arg;
    int k = 0;
    int y;
    int x;

    usleep(1000000);

    while (drones->seq[k] != NULL) {
    pthread_mutex_lock(&mutex_r);
    y = drones->y;
    x = drones->x;
        switch (drones->seq[k]) {
            case 'M':
                switch (drones->ori) {
                    case 0:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y-1][x]!=1 ){
                           y--;
                        }
                        p1->plateau[y][x] = 5;
                        break;
                    case 1:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x-1]!=1){
                           x--;
                        }
                        p1->plateau[y][x] = 6;
                        break;
                    case 2:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y+1][x]!=1){
                           y++;
                        }
                        p1->plateau[y][x] = 7;
                        break;
                    case 3:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x+1]!=1){
                           x++;
                        }
                        p1->plateau[y][x] = 8;
                        break;
                }
                break;
            case 'B':
                switch (drones->ori) {
                    case 0:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y+1][x]!=1){
                           y++;
                        }
                        p1->plateau[y][x] = 5;
                        break;
                    case 1:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x+1]!=1){
                           x++;
                        }
                        p1->plateau[y][x] = 6;
                        break;
                    case 2:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y-1][x]!=1){
                           y--;
                        }
                        p1->plateau[y][x] = 7;
                        break;
                    case 3:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x-1]!=1){
                           x--;
                        }
                        p1->plateau[y][x] = 8;
                        break;
                }
                break;
            case 'R':
                drones->ori = (drones->ori + 3) % 4;
                switch (drones->ori){
                case 0 :
                    p1->plateau[y][x]= 5;
                    break;

                case 1 :
                    p1->plateau[y][x]= 6;
                    break;

                case 2 :
                    p1->plateau[y][x]= 7;
                    break;

                case 3 :
                    p1->plateau[y][x]= 8;
                    break;
                }
                break;

            case 'L':
                drones->ori = (drones->ori + 5) % 4;
                switch (drones->ori){
                case 0 :
                    p1->plateau[y][x]= 5;
                    break;

                case 1 :
                    p1->plateau[y][x]= 6;
                    break;

                case 2 :
                    p1->plateau[y][x]= 7 ;
                    break;

                case 3 :
                    p1->plateau[y][x]= 8;
                    break;
                }
                break;
        }
      pthread_mutex_unlock(&mutex_r);
      drones->y = y;
      drones->x = x;
      usleep(1000000);
      k++;
    }
    return NULL;
    }



int main() {
    char tableau[TAILLE_MSG][TAILLE_MSG];
    int serverSocket, newSocket;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t addrSize;
    char msg[TAILLE_MSG];

    // Créer une socket pour le serveur
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        perror("Erreur lors de la création de la socket serveur");
        exit(EXIT_FAILURE);
    }

    // Configurer l'adresse du serveur
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Lier la socket à l'adresse et au port
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        perror("Erreur lors de la liaison de la socket serveur");
        close(serverSocket);
        exit(EXIT_FAILURE);
    }

    // Mettre le serveur en mode écoute
    if (listen(serverSocket, 10) == -1) {
        perror("Erreur lors de la mise en mode écoute de la socket serveur");
        close(serverSocket);
        exit(EXIT_FAILURE);
    }

    printf("Le serveur attend des connexions...\n");

    // Accepter la connexion entrante d'un client
    addrSize = sizeof(clientAddr);
    newSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &addrSize);
    if (newSocket == -1) {
        perror("Erreur lors de l'acceptation de la connexion du client");
        close(serverSocket);
        exit(EXIT_FAILURE);
    }

    printf("Le serveur a accepté la connexion du client.\n");

    // Recevoir des données du client
    recv(newSocket, tableau, 1024, 0);
    for (int i = 0; i < 32; i++) {
    for (int j = 0; j < 32; j++) {
        printf("%c", tableau[i][j]);
    }
    printf("\n");
}

    // Fermer les sockets
    close(newSocket);
    close(serverSocket);

    return 0;
}

