#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#include "utilitaire.h"
#include "Drone.h"

#define PORT 8080

int clientSocket;
struct sockaddr_in serverAddr;

Plateau p, *p1;

void main() {
    
    char tableau[MAX_TAILLE][MAX_TAILLE];
    char pos_finale[MAX_TAILLE][MAX_TAILLE];
    int nbDrone;
    char o;
    
    // Appeler la fonction pour lire le fichier
    if (lireFichier("commande.txt", tableau, &nbDrone) != 0) {
        return 1; // Quitter le programme en cas d'erreur
    }
    
    sscanf(tableau[0], "%d %d", &p.L, &p.C);
    printf("Taille de la carte : %s", tableau);
    
    Drone drones[nbDrone];

    for (int i = 1; i < nbDrone; i++){
        char o;
        sscanf(tableau[i], "%d %d %c %s",  &drones[i].x, &drones[i].y, &o, &drones[i].seq);
        drones[i].id = i;
        printf("\n\n");
        printf("Position initiale drone %d : %d %d %c \n", drones[i].id, drones[i].x, drones[i].y, o);

            switch(o) {
        case 'N':
                drones[i].ori = 0;
            break;
        case 'E':
                drones[i].ori = 1;
            break;
        case 'S':
                drones[i].ori = 2;
            break;
        case 'O':
                drones[i].ori = 3;
            break;
    }
    }
    printf("\n\n");

    // Créer la socket client
    if ((clientSocket = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("Erreur lors de la création de la socket");
        exit(EXIT_FAILURE);
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);

    // Convertir l'adresse IP de chaîne vers la forme binaire
    if (inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr) <= 0) {
        perror("Erreur lors de la conversion de l'adresse IP");
        exit(EXIT_FAILURE);
    }
    
    // Établir la connexion avec le serveur
    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1) {
        perror("Erreur lors de la connexion au serveur");
        exit(EXIT_FAILURE);
    }
    
    send(clientSocket, &nbDrone, sizeof(int), 0);
    // Envoyer des données au serveur
    send(clientSocket, &tableau, sizeof(tableau), 0);
    
    recv(clientSocket, &pos_finale, sizeof(pos_finale), 0);
    
     for (int j = 1; j<nbDrone; j++){
      printf("Position finale drone %d : %s\n",j ,pos_finale[j]);
    }

    // Fermer la socket client
    close(clientSocket);
}

