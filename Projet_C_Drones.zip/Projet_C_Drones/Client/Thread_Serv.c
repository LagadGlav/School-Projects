#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

#include "Drone.h"
#include "utilitaire.h"

Plateau p, *p1;

pthread_mutex_t mutex_r = PTHREAD_MUTEX_INITIALIZER;

