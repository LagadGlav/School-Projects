#ifndef UTILITAIRE_H_INCLUDED
#define UTILITAIRE_H_INCLUDED

#define MAX_DRONE 5
#define MAX_L 30
#define MAX_C 30
#define MAX_TAILLE 30


int _kbhit();
char _getch();
int lireFichier(const char *nomFichier, char tableau[MAX_TAILLE][MAX_TAILLE], int *nbDrone);


#endif // UTILITAIRE_H_INCLUDED
