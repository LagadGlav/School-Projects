#!/bin/bash

# Définition des chemins
SRC_DIR=/home/baptiste/Client
OBJ_DIR=$SRC_DIR/obj
BIN_DIR=$SRC_DIR
TARGET=client

# Nettoyage des fichiers objets
rm -f $OBJ_DIR/*.o

# Compilation des fichiers objets
gcc -Wall -g -c $SRC_DIR/Client.c -o $OBJ_DIR/Client.o
gcc -Wall -g -c $SRC_DIR/utilitaire.c -o $OBJ_DIR/utilitaire.o

# Compilation de l'exécutable
gcc -Wall -g -o $BIN_DIR/$TARGET $OBJ_DIR/*.o

