#ifndef SERVEUR_H_INCLUDED
#define SERVEUR_H_INCLUDED

int main_Serv();
void gen_plateau_Serv(void *arg);
void *deplacer_drone_Serv(void *arg);

#endif // SERVEUR_H

