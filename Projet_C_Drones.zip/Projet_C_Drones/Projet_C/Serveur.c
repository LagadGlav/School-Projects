#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <time.h>
#include <pthread.h>

#include "Drone.h"
#include "utilitaire.h"

Plateau ps, *p1s;

int serverSocket, newSocket;
struct sockaddr_in serverAddr, clientAddr;
socklen_t addrSize;
    

pthread_mutex_t mutex_r = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t affiche_Cond_S = PTHREAD_COND_INITIALIZER;

#define PORT 8080

void *affichage_Serv(void *arg) {
system("clear");
    Plateau *pl = (Plateau *)arg;
    int k = 0;
    while (k<75) {
        pthread_mutex_lock(&mutex_r);
        pthread_cond_signal(&affiche_Cond_S);
        printf("\n");
        for (int i = 0; i < pl->L; i++) {
            for (int j = 0; j < pl->C; j++) {
                if (pl->plateau[i][j] == 1) {
                    printf("#");
                } else if (p1s->plateau[i][j] == 0) {
                    printf(" ");
                } else if (p1s->plateau[i][j] == 3) {
                    printf("|");
                } else if (p1s->plateau[i][j] == 4) {
                    printf("-");
                } else if (p1s->plateau[i][j] == 2) {
                    printf("+");
                } else if (p1s->plateau[i][j] == 5) {
                    printf("^");
                } else if (p1s->plateau[i][j] == 6) {
                    printf("<");
                } else if (p1s->plateau[i][j] == 7) {
                    printf("v");
                } else if (p1s->plateau[i][j] == 8) {
                    printf(">");
                }
                printf(" ");
            }
            printf("\n");
        }

        pthread_mutex_unlock(&mutex_r);
        usleep(500000);
    k++;
    }
    return NULL;
}

void gen_plateau_Serv(void *arg){
    Plateau *p1s = (Plateau *)arg;
    time_t t;
    srand((unsigned) time(&t));
    for(int i = 0; i<p1s->L; i++){
       for(int j = 0; j<p1s->C; j++){
            if (i==0 || j==0 || i==p1s->L-1 || j==p1s->C-1 || rand() % 100>=90){
                p1s->plateau[i][j] = 1;
            }
            else{p1s->plateau[i][j]= 0;}
        }
    }
}



void *deplacer_drone_Serv(void *arg){
    
    Drone *drones = (Drone *)arg;
    int k = 0;
    int y;
    int x;
    while (drones->seq[k] != NULL) {
    pthread_mutex_lock(&mutex_r);
    pthread_cond_wait(&affiche_Cond_S, &mutex_r);
    y = drones->y;
    x = drones->x;
        switch (drones->seq[k]) {
            case 'M':
                switch (drones->ori) {
                    case 0:
                        p1s->plateau[y][x] = 3;
                        if (p1s->plateau[y-1][x]!=1 ){
                           y--;
                        }
                        p1s->plateau[y][x] = 5;
                        break;
                    case 1:
                        p1s->plateau[y][x] = 4;
                        if (p1s->plateau[y][x-1]!=1){
                           x--;
                        }
                        p1s->plateau[y][x] = 6;
                        break;
                    case 2:
                        p1s->plateau[y][x] = 3;
                        if (p1s->plateau[y+1][x]!=1){
                           y++;
                        }
                        p1s->plateau[y][x] = 7;
                        break;
                    case 3:
                        p1s->plateau[y][x] = 4;
                        if (p1s->plateau[y][x+1]!=1){
                           x++;
                        }
                        p1s->plateau[y][x] = 8;
                        break;
                }
                break;
            case 'B':
                switch (drones->ori) {
                    case 0:
                        p1s->plateau[y][x] = 3;
                        if (p1s->plateau[y+1][x]!=1){
                           y++;
                        }
                        p1s->plateau[y][x] = 5;
                        break;
                    case 1:
                        p1s->plateau[y][x] = 4;
                        if (p1s->plateau[y][x+1]!=1){
                           x++;
                        }
                        p1s->plateau[y][x] = 6;
                        break;
                    case 2:
                        p1s->plateau[y][x] = 3;
                        if (p1s->plateau[y-1][x]!=1){
                           y--;
                        }
                        p1s->plateau[y][x] = 7;
                        break;
                    case 3:
                        p1s->plateau[y][x] = 4;
                        if (p1s->plateau[y][x-1]!=1){
                           x--;
                        }
                        p1s->plateau[y][x] = 8;
                        break;
                }
                break;
            case 'R':
                drones->ori = (drones->ori + 3) % 4;
                switch (drones->ori){
                case 0 :
                    p1s->plateau[y][x]= 5;
                    break;

                case 1 :
                    p1s->plateau[y][x]= 6;
                    break;

                case 2 :
                    p1s->plateau[y][x]= 7;
                    break;

                case 3 :
                    p1s->plateau[y][x]= 8;
                    break;
                }
                break;

            case 'L':
                drones->ori = (drones->ori + 5) % 4;
                switch (drones->ori){
                case 0 :
                    p1s->plateau[y][x]= 5;
                    break;

                case 1 :
                    p1s->plateau[y][x]= 6;
                    break;

                case 2 :
                    p1s->plateau[y][x]= 7 ;
                    break;

                case 3 :
                    p1s->plateau[y][x]= 8;
                    break;
                }
                break;
        }
      
      //send(newSocket, p1s->plateau, sizeof(p1s->plateau), 0);
      pthread_mutex_unlock(&mutex_r);
      drones->y = y;
      drones->x = x;
      k++;
    }
    return NULL;
    }
    


int main_Serv() {
    char tableau[MAX_TAILLE][MAX_TAILLE];
    int nbDrone;
    char pos_finale[MAX_TAILLE][MAX_TAILLE];
    char o;

    // Créer une socket pour le serveur
    serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        perror("Erreur lors de la création de la socket serveur");
        exit(EXIT_FAILURE);
    }

    // Configurer l'adresse du serveur
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    // Lier la socket à l'adresse et au port
    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        perror("Erreur lors de la liaison de la socket serveur");
        close(serverSocket);
        exit(EXIT_FAILURE);
    }

    // Mettre le serveur en mode écoute
    if (listen(serverSocket, 10) == -1) {
        perror("Erreur lors de la mise en mode écoute de la socket serveur");
        close(serverSocket);
        exit(EXIT_FAILURE);
    }

    printf("Le serveur attend des connexions...\n");

    // Accepter la connexion entrante d'un client
    addrSize = sizeof(clientAddr);
    newSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &addrSize);
    if (newSocket == -1) {
        perror("Erreur lors de l'acceptation de la connexion du client");
        close(serverSocket);
        exit(EXIT_FAILURE);
    }

    printf("Le serveur a accepté la connexion du client.\n");
    
    recv(newSocket, &nbDrone, sizeof(int), 0);
  
    // Recevoir des données du client
    recv(newSocket, &tableau, sizeof(tableau), 0);
  
  sscanf(tableau[0], "%d %d", &ps.L, &ps.C);
  ps.L = ps.L + 2;
  ps.C = ps.C + 2;
  p1s = &ps;
  gen_plateau_Serv(p1s);
  
  Drone drones[nbDrone];
  
  printf("Taille de la carte : %s", tableau[0]);
    // Recevoir des données du client
  for (int i = 1; i < nbDrone; i++){
        sscanf(tableau[i], "%d %d %c %s",  &drones[i].x, &drones[i].y, &o, &drones[i].seq);
        drones[i].id = i;
        printf("\n\n");
        printf("Position initiale drone %d : %d %d %c \n", drones[i].id, drones[i].x, drones[i].y, o);
        
            switch(o) {
        case 'N':
                drones[i].ori = 0;
            break;
        case 'E':
                drones[i].ori = 3;
            break;
        case 'S':
                drones[i].ori = 2;
            break;
        case 'O':
                drones[i].ori = 1;
            break;
    }
  }
  
    
    printf("Appuyez sur une touche pour lancer la simulation \n");
    while (!_kbhit()) {
        }
        _getch();
    pthread_t thread_affichage;
    pthread_t threads[nbDrone-1];
    int result;
    
    for (int i = 0; i < nbDrone; i++) {
    
        result = pthread_create(&threads[i], NULL, deplacer_drone_Serv, (void *)&drones[i]);
        if (result != 0) {
            fprintf(stderr, "Erreur lors de la creation du thread %d\n", i);
            return 1;
        }
    }
    
    pthread_create(&thread_affichage, NULL, affichage_Serv, (void *)p1s);
    
    for (int i = 0; i < nbDrone; i++) {
        result = pthread_join(threads[i], NULL);
        if (result !=0){
          break;
        }
    }
    pthread_join(thread_affichage, NULL);
    printf("\nFin des deplacements\n");
    
    for (int g = 1; g<nbDrone; g++){
      switch (drones[g].ori) {
      case 0:
          o = 'N';
          break;
      case 1:
          o = 'O';
          break;
      case 2:
          o = 'S';
          break;
      case 3:
          o = 'E';
         break;
      default:
          // Gérer le cas où drones[i].ori n'est pas dans les valeurs attendues
          break;
    }
      snprintf(pos_finale[g], sizeof(pos_finale[g]), "%d %d %c", drones[g].x, drones[g].y, o);
    }
    
    send(newSocket, pos_finale, sizeof(tableau), 0);
    // Fermer les sockets
    close(newSocket);
    close(serverSocket);

    return 0;
}

