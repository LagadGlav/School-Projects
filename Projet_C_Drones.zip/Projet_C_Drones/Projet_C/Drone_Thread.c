#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

#include "Drone.h"
#include "utilitaire.h"

Plateau p, *p1;

pthread_mutex_t mutex_t = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t affiche_Cond = PTHREAD_COND_INITIALIZER;

int sortie_affichage = 1;

void gen_plateau_Thread(void *arg){
    Plateau *p1 = (Plateau *)arg;
    time_t t;
    srand((unsigned) time(&t));
    for(int i = 0; i<p1->L; i++){
       for(int j = 0; j<p1->C; j++){
            if (i==0 || j==0 || i==p1->L-1 || j==p1->C-1 || rand() % 100>=90){
                p1->plateau[i][j] = 1;
            }
            else{p1->plateau[i][j]= 0;}
        }
    }
}


void *affichage_Thread(void *arg) {
system("clear");
    Plateau *pl = (Plateau *)arg;
    int k = 0;
    while (k<100) {
        pthread_mutex_lock(&mutex_t);
        pthread_cond_signal(&affiche_Cond);
        printf("\n");
        for (int i = 0; i < pl->L; i++) {
            for (int j = 0; j < pl->C; j++) {
                if (pl->plateau[i][j] == 1) {
                    printf("#");
                } else if (pl->plateau[i][j] == 0) {
                    printf(" ");
                } else if (pl->plateau[i][j] == 3) {
                    printf("|");
                } else if (pl->plateau[i][j] == 4) {
                    printf("-");
                } else if (pl->plateau[i][j] == 2) {
                    printf("+");
                } else if (p1->plateau[i][j] == 5) {
                    printf("^");
                } else if (p1->plateau[i][j] == 6) {
                    printf("<");
                } else if (p1->plateau[i][j] == 7) {
                    printf("v");
                } else if (p1->plateau[i][j] == 8) {
                    printf(">");
                }
                printf(" ");
            }
            printf("\n");
        }

        pthread_mutex_unlock(&mutex_t);
        usleep(500000);
    k++;
    }
    return NULL;
}


void *deplacer_drone_Thread(void *arg){
    Drone *drones = (Drone *)arg;
    int k = 0;
    int y;
    int x;

    while (drones->seq[k] != NULL) {
    pthread_mutex_lock(&mutex_t);
    pthread_cond_wait(&affiche_Cond, &mutex_t);
    y = drones->y;
    x = drones->x;
        switch (drones->seq[k]) {
            case 'M':
                switch (drones->ori) {
                    case 0:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y-1][x]!=1 ){
                           y--;
                        }
                        p1->plateau[y][x] = 5;
                        break;
                    case 1:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x-1]!=1){
                           x--;
                        }
                        p1->plateau[y][x] = 6;
                        break;
                    case 2:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y+1][x]!=1){
                           y++;
                        }
                        p1->plateau[y][x] = 7;
                        break;
                    case 3:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x+1]!=1){
                           x++;
                        }
                        p1->plateau[y][x] = 8;
                        break;
                }
                break;
            case 'B':
                switch (drones->ori) {
                    case 0:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y+1][x]!=1){
                           y++;
                        }
                        p1->plateau[y][x] = 5;
                        break;
                    case 1:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x+1]!=1){
                           x++;
                        }
                        p1->plateau[y][x] = 6;
                        break;
                    case 2:
                        p1->plateau[y][x] = 3;
                        if (p1->plateau[y-1][x]!=1){
                           y--;
                        }
                        p1->plateau[y][x] = 7;
                        break;
                    case 3:
                        p1->plateau[y][x] = 4;
                        if (p1->plateau[y][x-1]!=1){
                           x--;
                        }
                        p1->plateau[y][x] = 8;
                        break;
                }
                break;
            case 'R':
                drones->ori = (drones->ori + 3) % 4;
                switch (drones->ori){
                case 0 :
                    p1->plateau[y][x]= 5;
                    break;

                case 1 :
                    p1->plateau[y][x]= 6;
                    break;

                case 2 :
                    p1->plateau[y][x]= 7;
                    break;

                case 3 :
                    p1->plateau[y][x]= 8;
                    break;
                }
                break;

            case 'L':
                drones->ori = (drones->ori + 5) % 4;
                switch (drones->ori){
                case 0 :
                    p1->plateau[y][x]= 5;
                    break;

                case 1 :
                    p1->plateau[y][x]= 6;
                    break;

                case 2 :
                    p1->plateau[y][x]= 7 ;
                    break;

                case 3 :
                    p1->plateau[y][x]= 8;
                    break;
                }
                break;
        }
      pthread_mutex_unlock(&mutex_t);
      drones->y = y;
      drones->x = x;
      k++;
    }
    return NULL;
    }


int main_Thread(){

    char tableau[MAX_TAILLE][MAX_TAILLE];
    int nbDrone;
    char o;


    // Appeler la fonction pour lire le fichier
    if (lireFichier("commande.txt", tableau, &nbDrone) != 0) {

        return 1; // Quitter le programme en cas d'erreur
    }
    sscanf(tableau[0], "%d %d", &p.L, &p.C);
    p.L = p.L + 2;
    p.C = p.C + 2;
    p1 = &p;
    gen_plateau_Thread(p1);
    Drone drones[nbDrone];

    printf("\nTaille de la carte : %s", tableau[0]);

    for (int i = 1; i < nbDrone; i++){
        char o;
        sscanf(tableau[i], "%d %d %c %s",  &drones[i].x, &drones[i].y, &o, &drones[i].seq);
        drones[i].id = i;
        printf("\n\n");
        printf("Position initiale drone %d : %d %d %c \n", drones[i].id, drones[i].x, drones[i].y, o);

            switch(o) {
        case 'N':
                drones[i].ori = 0;
            break;
        case 'E':
                drones[i].ori = 3;
            break;
        case 'S':
                drones[i].ori = 2;
            break;
        case 'O':
                drones[i].ori = 1;
            break;
    }
    }
    printf("\n\n");
    printf("Appuyez sur une touche pour lancer la simulation \n");
      while (!_kbhit()) {
        }
        _getch();
        
    pthread_t thread_affichage;
    pthread_t threads[nbDrone-1];
    int result;

    for (int i = 1; i < nbDrone; i++) {
        result = pthread_create(&threads[i], NULL, deplacer_drone_Thread, (void *)&drones[i]);
        if (result != 0) {
            fprintf(stderr, "Erreur lors de la création du thread %d\n", i);
            return 1;
        }
    }
    
    pthread_create(&thread_affichage, NULL, affichage_Thread, (void *)p1);
  
    for (int i = 0; i < nbDrone; i++) {
        result = pthread_join(threads[i], NULL);
        if (result !=0){
          break;
        }
    }
    
     pthread_join(thread_affichage, NULL);

     for (int i = 1; i < nbDrone; i++){
     switch (drones[i].ori) {
    case 0:
        o = 'N';
        break;
    case 1:
        o = 'O';
        break;
    case 2:
        o = 'S';
        break;
    case 3:
        o = 'E';
        break;
    default:
        // Gérer le cas où drones[i].ori n'est pas dans les valeurs attendues
        break;
}
        printf("\n\n");
        printf("Position finale drone %d : %d %d %c \n", drones[i].id, drones[i].x, drones[i].y, o);
     }
     return 1;
}

