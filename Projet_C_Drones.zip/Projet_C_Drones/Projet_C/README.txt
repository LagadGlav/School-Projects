README

Projet universitaire :
- Exécution des commandes de déplacement pour chaqu'un des drones.
- Exécution simultanée à l'aide de threads
- Envoie et réception des commandes via liaison tcp 

Projet conçu et exécutable sous Linux/Ubuntu
Pour exécuter, commande sur le terminal : ./Projet_C
