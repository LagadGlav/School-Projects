#ifndef DRONE_THREAD_H_INCLUDED
#define DRONE_THREAD_H_INCLUDED

int main_Thread();
void *deplacer_drone_Thread(void *arg);
void *affichage_Thread(void *arg);
void gen_plateau_Thread(void *arg);

#endif // DRONE_THREAD_H_INCLUDED
