#!/bin/bash

# Définition des chemins
SRC_DIR=/home/baptiste/Projet_C
OBJ_DIR=$SRC_DIR/obj
BIN_DIR=$SRC_DIR
TARGET=Projet_C

# Nettoyage des fichiers objets
rm -f $OBJ_DIR/*.o

# Compilation des fichiers objets
gcc -Wall -g -c $SRC_DIR/Drone_Seq.c -o $OBJ_DIR/Drone_Seq.o
gcc -Wall -g -c $SRC_DIR/Drone_Thread.c -o $OBJ_DIR/Drone_Thread.o
gcc -Wall -g -c $SRC_DIR/Main.c -o $OBJ_DIR/Main.o
gcc -Wall -g -c $SRC_DIR/Serveur.c -o $OBJ_DIR/Serveur.o
gcc -Wall -g -c $SRC_DIR/utilitaire.c -o $OBJ_DIR/utilitaire.o

# Compilation de l'exécutable
gcc -Wall -g -o $BIN_DIR/$TARGET $OBJ_DIR/*.o



