#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

#include "utilitaire.h"


int gen_plateau1(int L, int C, int plateau[L][C]){
    time_t t;;
    srand((unsigned) time(&t));
    for(int i = 0; i<L; i++){
       for(int j = 0; j<C; j++){
            if (i==0 || j==0 || i==L-1 || j==C-1 || rand() % 100>=90){
                plateau[i][j] = 1;
            }
            else{plateau[i][j]= 0;}
        }
    }
    return plateau;
}

void afficher(int L,int C, int plateau[L][C]){
system("clear");
    for (int i = 0; i < L; i++) {
        for (int j = 0; j < C; j++){
            if (plateau[i][j]== 1) {
                printf("#");
            }
            if (plateau[i][j]==0){
                printf(" ");
            }
            if (plateau[i][j]==3){
                printf("|");
            }
            if (plateau[i][j]==4){
                printf("-");
            }
            if (plateau[i][j]==5){
                printf("^");
            }
            if (plateau[i][j]==6){
                printf("<");
            }
            if (plateau[i][j]==7){
                printf("v");
            }
            if (plateau[i][j]==8){
                printf(">");
            }
        printf(" ");
        }
        printf("\n");
    }
    return;

}
int chemin(int j, int x, int y, int ori, char seq[15], int L, int C, int plateau[L][C], char pos_finale[MAX_TAILLE][MAX_TAILLE]){
    char o;
    plateau[y][x] = 2;
    int k = 0;
    
    while (seq[k] != NULL) {
        switch (seq[k]) {
            case 'M':
                switch (ori) {
                    case 0:
                        plateau[y][x] = 3;
                        if (plateau[y-1][x]!=1){
                           y--;
                        }
                        plateau[y][x] = 5;
                        break;
                    case 1:
                        plateau[y][x] = 4;
                        if (plateau[y][x-1]!=1){
                           x--;
                        }
                        plateau[y][x] = 6;
                        break;
                    case 2:
                        plateau[y][x] = 3;
                        if (plateau[y+1][x]!=1){
                           y++;
                        }
                        plateau[y][x] = 7;
                        break;
                    case 3:
                        plateau[y][x] = 4;
                        if (plateau[y][x+1]!=1){
                           x++;
                        }
                        plateau[y][x] = 8;
                        break;
                }
                break;
            case 'B':
                switch (ori) {
                    case 0:
                        plateau[y][x] = 3;
                        if (plateau[y+1][x]!=1){
                           y++;
                        }
                        plateau[y][x] = 5;
                        break;
                    case 1:
                        plateau[y][x] = 4;
                        if (plateau[y][x+1]!=1){
                           x++;
                        }
                        plateau[y][x] = 6;
                        break;
                    case 2:
                        plateau[y][x] = 3;
                        if (plateau[y-1][x]!=1){
                           y--;
                        }
                        plateau[y][x] = 7;
                        break;
                    case 3:
                        plateau[y][x] = 4;
                        if (plateau[y][x-1]!=1){
                           x--;
                        }
                        plateau[y][x] = 8;
                        break;
                }
                break;
            case 'R':
                ori = (ori + 3) % 4;
                switch (ori){
                case 0 :
                    plateau[y][x]= 5;
                    break;

                case 1 :
                    plateau[y][x]= 6;
                    break;

                case 2 :
                    plateau[y][x]= 7;
                    break;

                case 3 :
                    plateau[y][x]= 8;
                    break;
                }
                break;

            case 'L':
                ori = (ori + 5) % 4;
                switch (ori){
                case 0 :
                    plateau[y][x]= 5;
                    break;

                case 1 :
                    plateau[y][x]= 6;
                    break;

                case 2 :
                    plateau[y][x]= 7 ;
                    break;

                case 3 :
                    plateau[y][x]= 8;
                    break;
                }
                break;
        }
        
          
    
        afficher(L, C, plateau);
        
        printf("\n");
    printf("Appuyez sur une touche pour continuer");
        while (!_kbhit()) {
            
        }
        _getch();

        k++;
    }
    
    snprintf(pos_finale[j], sizeof(pos_finale[k]), "%d %d %d", x, y, ori);


    return 0;
}


int main_seq() {
    char tableau[MAX_TAILLE][MAX_TAILLE];
    char pos_finale[MAX_TAILLE][MAX_TAILLE];
    int nbDrone;
    int L;
    int C;
    int x;
    int y;
    int ori;
    char o;
    char seq[15];


    // Appeler la fonction pour lire le fichier
    if (lireFichier("commande.txt", tableau, &nbDrone) != 0) {
        return 1; // Quitter le programme en cas d'erreur
    }
    sscanf(tableau[0], "%d %d", &L, &C);
    L = L + 2;
    C = C + 2;

    int plateau[L][C];
    gen_plateau1(L, C, plateau);
    
    printf("\n Taille de la carte : %d %d \n\n", L, C);
    
    for (int j = 1; j<nbDrone; j++){
      sscanf(tableau[j], "%d %d %c %s", &x, &y, &o, &seq);
      printf("Position initiale drone %d : %d %d %c \n", j, x, y, o);
      printf("Commande : %s \n", seq);
    }
    
    printf("Appuyez sur une touche pour lancer la simulation \n\n");
    
    while (!_kbhit()) {
        }
        _getch();

    afficher(L, C, plateau);
    for (int k = 1; k<nbDrone; k++){
    sscanf(tableau[k], "%d %d %c %s", &x, &y, &o, &seq);
    switch(o) {
        case 'N':
            ori = 0;
            break;
        case 'E':
            ori = 3;
            break;
        case 'S':
            ori = 2;
            break;
        case 'O':
            ori = 1;
            break;
    }
    
        
    chemin(k ,x, y, ori, seq, L, C, plateau, pos_finale);
    
    }
    printf("Orientations : \n N = 0 O = 1 S = 2 E = 3\n");
    
    for (int j = 1; j<nbDrone; j++){
      
      printf("\nPosition finale drone %d : %s\n",j ,pos_finale[j]);
    }
    return 0;
}


