#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include "utilitaire.h"
#include "Drone.h"

int lireFichier(const char *nomFichier, char tableau[MAX_TAILLE][MAX_TAILLE], int *nbDrone) {
    FILE *file = fopen(nomFichier, "r");
    if (file == NULL) {
        fprintf(stderr, "Impossible d'ouvrir le fichier.\n");
        return 1;
    }

    int ligne = 0;

    while (fgets(tableau[ligne], MAX_TAILLE, file) != NULL && ligne < MAX_DRONE) {
        int len = strlen(tableau[ligne]);
        if (len > 0 && tableau[ligne][len - 1] == '\n') {
            tableau[ligne][len - 1] = '\0';
        }
        ligne++;
    }
    *nbDrone = ligne;

    fclose(file);
    return 0;
}

int _kbhit() {
    struct termios oldt, newt;
    int ch;
    int oldf;

    // Obtient les paramètres du terminal actuel
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;

    // Désactive la mise en mémoire tampon et l'affichage des caractères
    newt.c_lflag &= ~(ICANON | ECHO);

    // Applique les nouveaux paramètres du terminal
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    // Récupère le caractère (s'il y en a un)
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    fcntl(STDIN_FILENO, F_SETFL, oldf);

    // Restaure les paramètres du terminal
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);

    // Si un caractère a été lu, remet le caractère dans le flux d'entrée
    if(ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }

    return 0;
}

char _getch() {
    char buf = 0;
    struct termios old = {0};
    fflush(stdout);

    // Désactive la mise en mémoire tampon
    if(tcgetattr(0, &old) < 0)
        perror("tcsetattr()");
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    old.c_cc[VMIN] = 1;
    old.c_cc[VTIME] = 0;
    if(tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");

    // Lit le caractère
    if(read(0, &buf, 1) < 0)
        perror ("read()");

    // Rétablit les paramètres du terminal
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if(tcsetattr(0, TCSADRAIN, &old) < 0)
        perror ("tcsetattr ~ICANON");

    return buf;
}


