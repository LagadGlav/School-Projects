#ifndef DRONE_H_INCLUDED
#define DRONE_H_INCLUDED

#define MAX_DRONE 5
#define MAX_L 30
#define MAX_C 30
#define MAX_TAILLE 30
#define MAX_LIGNES 5

typedef struct {
    int L;
    int C;
    int plateau[MAX_L][MAX_C];
} Plateau;

typedef struct {
    int id;
    int x;
    int y;
    int ori;
    char seq[10];
} Drone;

void gen_plateau(void *arg);

#endif // DRONE_H_INCLUDED
