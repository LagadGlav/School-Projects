#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>


#include "Drone.h"
#include "Drone_Seq.h"
#include "Drone_Thread.h"
#include "Serveur.h"

int main(){

  int choix;

    printf("Choisissez la version du projet :\n");
    printf("1. Version sequentielle\n");
    printf("2. Version concurrente\n");
    printf("3. Version reseau\n");
    printf("Votre choix : ");
    scanf("%d", &choix);

    switch (choix) {
        case 1:
            main_seq();
            break;
        case 2:
            main_Thread();
            break;
        case 3:
            main_Serv();
            break;
        default:
            
            printf("Choix invalide.\n");
            break;
    }

    return 0;
}
