#ifndef DRONE_SEQ_H_INCLUDED
#define DRONE_SEQ_H_INCLUDED

int main_seq();


#endif // DRONE_SEQ_H_INCLUDED
